package com.example.android.study;

public class UserInformation {
    public String Name;
    public String Email;
    public String Phone;
    public String Location;




    public UserInformation(){

    }

    public UserInformation(String Name, String Email, String Phone, String Location) {
        this.Name = Name;
        this.Email = Email;
        this.Location = Location;
        this.Phone = Phone;
    }




}
