package com.example.android.study;

public class upload {

    private String imageurl;


    public upload(String imageurl) {
        this.imageurl = imageurl;
    }

    public upload (){




    }






}
